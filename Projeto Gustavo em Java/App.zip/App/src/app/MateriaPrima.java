
package app;


public class MateriaPrima extends Produto {
    
    private String plantio;
    private String adubo;
    private String colheita;
    private String beneficiadoras;

    public String getPlantio() {
        return plantio;
    }

    public void setPlantio(String plantio) {
        this.plantio = plantio;
    }

    public String getAdubo() {
        return adubo;
    }

    public void setAdubo(String adubo) {
        this.adubo = adubo;
    }

    public String getColheita() {
        return colheita;
    }

    public void setColheita(String colheita) {
        this.colheita = colheita;
    }

    public String getBeneficiadoras() {
        return beneficiadoras;
    }

    public void setBeneficiadoras(String beneficiadoras) {
        this.beneficiadoras = beneficiadoras;
    }

    
    
    
}
    
    

