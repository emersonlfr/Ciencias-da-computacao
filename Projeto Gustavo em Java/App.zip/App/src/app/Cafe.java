
package app;


public class Cafe extends ProdutoAcabado {
    
    private String embalagem;
    private float valor;
    private String transporte;
    
    public Cafe(String embalagem) {
    this.embalagem = embalagem;
    }

    public String getEmbalagem() {
        return embalagem;
    }

    public void setEmbalagem(String embalagem) {
        this.embalagem = embalagem;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public String getTransporte() {
        return transporte;
    }

    public void setTransporte(String transporte) {
        this.transporte = transporte;
    }


   
 

    
    
    
    
}
