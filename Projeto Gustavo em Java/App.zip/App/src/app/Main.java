
package app;


public class Main {

    public static void main(String[] args) {
        Cafe cafe = new Cafe("Evolutto");
        
        
        cafe.setValor(10);
        cafe.setEmbalagem("Plastico");
        cafe.setTransporte("Caminhao");
        
        
        
        
        System.out.println(cafe.getEmbalagem());
        System.out.println("----------");
        System.out.println("Valor= R$ " + cafe.getValor());
        System.out.println("Material da embalagem = " + cafe.getEmbalagem());
        System.out.println("Transporte = " + cafe.getTransporte());
        System.out.println("---------");
        
        
        
        
        
    }
        
              
           
}
