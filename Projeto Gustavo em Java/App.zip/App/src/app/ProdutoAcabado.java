
package app;


public class ProdutoAcabado extends Produto {
    private String torrefacao;
    private String moagem;
    private String preparo;

    public String getTorrefacao() {
        return torrefacao;
    }

    public void setTorrefacao(String torrefacao) {
        this.torrefacao = torrefacao;
    }

    public String getMoagem() {
        return moagem;
    }

    public void setMoagem(String moagem) {
        this.moagem = moagem;
    }

    public String getPreparo() {
        return preparo;
    }

    public void setPreparo(String preparo) {
        this.preparo = preparo;
    }
    

  
    
    
    
    
    
}
